console.log("Hello World")
var app = angular.module("api", []);
app.controller("application", function($scope, $http, $interval, $timeout) {
});