function angGet(ele, url){
    return new Promise((resolve, reject)=>{
        ele.get(url).then((a)=>{
            resolve(a);
        }).catch((e)=>{
            reject(e)
        })
    })
}

function angCreateElement(obj, table, support){
    return new Promise((resolve, reject) => {
        support.post("/insertid/" + table, obj).then((a)=>{
            resolve(a);
        }).catch((e)=>{
            reject(e);
        })
    })
}

function angUpdateElement(obj, tb, support){
    var obj = {
        table: tb,
        data: obj
    }
    return new Promise((resolve, reject)=>{
        support.put("/update", obj).then((a)=>{
            resolve(a);
        }).catch((e)=>{
            reject(e);
        })
    })
}

function angDeleteElement(id, tb, support){
    return new Promise((resolve, reject)=>{
        support.get("/delete" + "?id=" + id + "&table=" + tb).then((a)=>{
            resolve(a);
        }).catch((e) => {
            reject(e);
        })
    })
}

function print(a){
    console.log(a);
}

function searchArray(key, value, array){
    for(i in array){
        if(array[i][key] == value){
            return array[i];
        }
    }
}

/**
 * You first need to create a formatting function to pad numbers to two digits…
 **/
function twoDigits(d) {
    if(0 <= d && d < 10) return "0" + d.toString();
    if(-10 < d && d < 0) return "-0" + (-1*d).toString();
    return d.toString();
}

/**
 * …and then create the method to output the date string as desired.
 * Some people hate using prototypes this way, but if you are going
 * to apply this to more than one Date object, having it as a prototype
 * makes sense.
 **/
Date.prototype.toMysqlFormat = function() {
    return this.getUTCFullYear() + "-" + twoDigits(1 + this.getUTCMonth()) + "-" + twoDigits(this.getUTCDate()) + " " + twoDigits(this.getUTCHours()) + ":" + twoDigits(this.getUTCMinutes()) + ":" + twoDigits(this.getUTCSeconds());
};